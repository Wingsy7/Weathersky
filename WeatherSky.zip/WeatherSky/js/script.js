/**
 * script.js - Script principal de la page météo interactive
 *
 * Ce script gère :
 * - le chargement des villes et départements depuis des fichiers JSON,
 * - la recherche par ville avec auto-complétion,
 * - la recherche par département,
 * - l’affichage de la carte interactive avec Leaflet,
 * - l’affichage des prévisions météo via l’API Open-Meteo.
 *
 * @author Cozma
 * @version 1.0
 * @since Avril 2025
 */

document.addEventListener("DOMContentLoaded", async () => {
  console.log("📦 script.js chargé");

  /** @type {HTMLSelectElement} */
  const depSelect = document.getElementById("departement");
  /** @type {HTMLInputElement} */
  const inputVille = document.getElementById("ville-ville");
  /** @type {HTMLElement} */
  const suggestions = document.getElementById("suggestions");
  /** @type {HTMLElement} */
  const container = document.getElementById("previsions");

  /** @type {Array<Object>} */
  let villes = [];
  /** @type {Array<Object>} */
  let departements = [];

  // Chargement des fichiers JSON contenant villes et départements
  try {
    const villesRes = await fetch("data/villes.json");
    const depRes = await fetch("data/departements.json");
    villes = await villesRes.json();
    departements = await depRes.json();
  } catch (e) {
    console.error("❌ Erreur chargement JSON :", e);
    return;
  }

  /**
   * Remplit la liste déroulante des départements.
   */
  departements.forEach(dep => {
    const opt = document.createElement("option");
    opt.value = dep.DEP;
    opt.textContent = `${dep.DEP} - ${dep.NCCENR}`;
    depSelect.appendChild(opt);
  });

  /**
   * Lorsqu’un département est sélectionné, une ville aléatoire du département est choisie
   * puis redirige vers `map.php` avec les paramètres nécessaires.
   */
  depSelect.addEventListener("change", () => {
    const code = depSelect.value;

    const villesDuDep = villes.filter(v => {
      const cp = String(v.Code_postal).padStart(5, '0');
      return cp.startsWith(code) && v.coordonnees_gps;
    });

    if (villesDuDep.length > 0) {
      const ville = villesDuDep[Math.floor(Math.random() * villesDuDep.length)];
      const [lat, lon] = ville.coordonnees_gps.split(',').map(coord => parseFloat(coord.trim()));

      if (!isNaN(lat) && !isNaN(lon)) {
        const url = `map.php?ville=${encodeURIComponent(ville.Nom_commune)}&lat=${lat}&lon=${lon}`;
        console.log("🧭 Redirection vers :", url);
        window.location.href = url;
      } else {
        console.warn("❌ Coordonnées invalides :", ville);
      }
    } else {
      alert("❌ Aucune ville trouvée dans ce département.");
    }
  });

  /**
   * Gère l’auto-complétion en affichant jusqu’à 5 suggestions de villes.
   */
  inputVille.addEventListener("input", () => {
    const nom = inputVille.value.trim().toLowerCase();
    suggestions.innerHTML = "";
    if (nom.length < 2) return;

    const resultats = villes.filter(v =>
      v.Nom_commune && v.Nom_commune.toLowerCase().startsWith(nom)
    ).slice(0, 5);

    resultats.forEach(v => {
      const li = document.createElement("li");
      li.textContent = `${v.Nom_commune} (${v.Code_postal})`;
      li.addEventListener("click", () => {
        const [lat, lon] = v.coordonnees_gps.split(',').map(Number);
        if (!isNaN(lat) && !isNaN(lon)) {
          window.location.href = `map.php?ville=${encodeURIComponent(v.Nom_commune)}&lat=${lat}&lon=${lon}`;
        }
      });
      suggestions.appendChild(li);
    });
  });

  // === Carte interactive Leaflet
  /**
   * Carte Leaflet centrée sur la France.
   * Affiche un marqueur sur une ville aléatoire par département.
   */
  const mapDep = L.map('map-departements').setView([46.5, 2.5], 6);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap contributors'
  }).addTo(mapDep);

  departements.forEach(dep => {
    const villesDuDep = villes.filter(v => {
      const cp = String(v.Code_postal);
      return cp.startsWith(dep.DEP) && v.coordonnees_gps;
    });

    const ville = villesDuDep.length > 0 ? villesDuDep[Math.floor(Math.random() * villesDuDep.length)] : null;

    if (ville) {
      const [lat, lon] = ville.coordonnees_gps.split(',').map(Number);
      if (!isNaN(lat) && !isNaN(lon)) {
        L.marker([lat, lon]).addTo(mapDep)
          .bindPopup(`<strong>${dep.NCCENR}</strong><br><a href="map.php?ville=${encodeURIComponent(ville.Nom_commune)}&lat=${lat}&lon=${lon}">📍 Voir météo</a>`);
      }
    }
  });

  // === Clic libre sur la carte
  mapDep.on("click", async function (e) {
    const lat = e.latlng.lat;
    const lon = e.latlng.lng;

    const popupText = await getMeteoPopup(lat, lon);
    L.marker([lat, lon]).addTo(mapDep).bindPopup(popupText).openPopup();
    await afficherPrevisions(lat, lon, `Coordonnées ${lat.toFixed(2)}, ${lon.toFixed(2)}`);
  });

  /**
   * Affiche la météo actuelle dans une infobulle.
   * @param {number} lat
   * @param {number} lon
   * @returns {Promise<string>}
   */
  async function getMeteoPopup(lat, lon) {
    try {
      const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true&timezone=Europe%2FParis&language=fr`;
      const res = await fetch(url);
      const data = await res.json();

      if (!data.current_weather) throw new Error("Pas de météo actuelle.");

      const { temperature, windspeed, weathercode } = data.current_weather;
      const icons = {
        0: "☀️", 1: "🌤️", 2: "⛅", 3: "☁️", 45: "🌫️",
        51: "🌦️", 61: "🌧️", 71: "❄️", 95: "⛈️"
      };
      const icon = icons[weathercode] || "❓";

      return `
        <strong>📍 Coordonnées</strong><br>
        🌍 ${lat.toFixed(2)}, ${lon.toFixed(2)}<br>
        ${icon} Température : ${temperature}°C<br>
        💨 Vent : ${windspeed} km/h
      `;
    } catch (e) {
      console.error("❌ Erreur météo popup :", e);
      return "Erreur météo.";
    }
  }

  /**
   * Affiche les prévisions météo sur 5 jours dans la section HTML.
   * @param {number} lat
   * @param {number} lon
   * @param {string} nom
   */
  async function afficherPrevisions(lat, lon, nom) {
    try {
      const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&daily=temperature_2m_min,temperature_2m_max,weathercode&timezone=Europe%2FParis&language=fr`;
      const res = await fetch(url);
      const data = await res.json();

      if (!data || !data.daily) throw new Error("Réponse vide de l'API météo");

      const jours = data.daily.time;
      const tmin = data.daily.temperature_2m_min;
      const tmax = data.daily.temperature_2m_max;
      const codes = data.daily.weathercode;

      container.innerHTML = `<h2>📆 Prévisions à ${nom}</h2><div class="previsions-wrap"></div>`;
      const wrap = container.querySelector(".previsions-wrap");

      const icons = {
        0: "☀️", 1: "🌤️", 2: "⛅", 3: "☁️", 45: "🌫️",
        51: "🌦️", 61: "🌧️", 71: "❄️", 95: "⛈️"
      };

      for (let i = 0; i < 5; i++) {
        const date = new Date(jours[i]);
        wrap.innerHTML += `
          <div class="day-card">
            <h3>${date.toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' })}</h3>
            <p>${icons[codes[i]] || "❓"}</p>
            <p>🌡️ ${tmin[i]}° / ${tmax[i]}°</p>
          </div>
        `;
      }
    } catch (err) {
      console.error("❌ Erreur prévisions :", err);
    }
  }

  // Affichage auto si la page contient des paramètres lat/lon
  const urlParams = new URLSearchParams(window.location.search);
  if (urlParams.has("lat") && urlParams.has("lon")) {
    const nom = urlParams.get("ville") || "Lieu";
    const lat = parseFloat(urlParams.get("lat"));
    const lon = parseFloat(urlParams.get("lon"));
    if (!isNaN(lat) && !isNaN(lon)) {
      await afficherPrevisions(lat, lon, nom);
    }
  }
});
