<?php
/**
 * Page Statistiques - WeatherSky
 *
 * Cette page affiche :
 * - Le nombre total de visiteurs
 * - Le top 5 des villes les plus recherchées
 * - Des graphiques Chart.js
 * - Des infos trafic (via Geoapify)
 * - Des infos boursières (via AlphaVantage)
 *
 * @package WeatherSky
 * @author  Votre Nom
 * @version 1.0
 */

// === Lecture des données de visites ===
$file = 'visites.json';
$visites = file_exists($file) ? json_decode(file_get_contents($file), true) : [];

/**
 * @var int $total Nombre total de visites
 */
$total = count($visites);

// === Statistiques par ville ===
$villes = [];
foreach ($visites as $v) {
    $ville = $v['ville'] ?? 'Inconnue';
    $villes[$ville] = ($villes[$ville] ?? 0) + 1;
}
arsort($villes);

/**
 * @var array $villesTop Les 5 villes les plus recherchées
 */
$villesTop = array_slice($villes, 0, 5);

// Sauvegarde des stats dans un fichier JSON utilisé côté JS
file_put_contents("stats_villes.json", json_encode($villesTop));
$villesStats = $villesTop;

// === Coordonnées utilisateur (GET ou cookie) ===
$lat = $_GET['lat'] ?? $_COOKIE['derniere_lat'] ?? null;
$lon = $_GET['lon'] ?? $_COOKIE['derniere_lon'] ?? null;

// === Inclusions principales ===
require "./include/header.inc.php";
require "./include/functions.inc.php";

// Détection du thème
$style_css = getStyle();

// Affiche l’en-tête HTML sans fermer le <head>
echo en_tete("Statistiques Météo", false);
?>

<!-- HTML de la page statistiques -->
<link rel="stylesheet" href="style.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>

<main class="main-part">
    <h1>📊 Statistiques du site météo</h1>
    <p><strong>Total de visiteurs :</strong> <?= $total ?></p>

    <!-- Graphique des 5 villes les plus recherchées -->
    <section>
        <h2>🏆 Top 5 des villes les plus visitées</h2>
        <canvas id="sitogramme" width="600" height="300"></canvas>
    </section>

    <!-- Graphique global de toutes les villes -->
    <section>
        <h2>🔎 Recherches par villes</h2>
        <canvas id="chartVilles" width="600" height="300"></canvas>
    </section>

    <!-- Infos Trafic avec Geoapify -->
    <section>
        <h2>🚗 Infos Trafic</h2>
        <div id="trafic">
            <?php if ($lat && $lon): ?>
                <?php
                $destLat = $lat + 0.3;
                $destLon = $lon + 0.3;
                $apiKey = "2806193fb62e4354b35df62f6399de95";
                $url = "https://api.geoapify.com/v1/routing?waypoints=$lat,$lon|$destLat,$destLon&mode=drive&apiKey=$apiKey";
                $response = @file_get_contents($url);

                if ($response !== false) {
                    $data = json_decode($response, true);
                    $props = $data['features'][0]['properties'] ?? null;

                    if ($props) {
                        echo "<p>📍 Position : " . round($lat, 3) . ", " . round($lon, 3) . "</p>";
                        echo "<p>📏 Distance : " . round($props['distance'] / 1000, 2) . " km</p>";
                        echo "<p>🕒 Durée estimée : " . round($props['time'] / 60) . " min</p>";
                    } else {
                        echo "<p>Erreur dans les données de Geoapify.</p>";
                    }
                } else {
                    echo "<p>Erreur de connexion à Geoapify.</p>";
                }
                ?>
            <?php else: ?>
                <p>Aucune position détectée (coordonnées non fournies).</p>
            <?php endif; ?>
        </div>
    </section>

    <!-- Infos Bourse -->
    <section>
        <h2>📈 Infos Boursières</h2>
        <div id="bourse">Chargement...</div>
    </section>

    <a href="index.php" class="btn">⬅ Retour à l'accueil</a>
</main>

<!-- Scripts pour les graphiques et la bourse -->
<script>
const villesTop = <?= json_encode($villesTop) ?>;
const villes = <?= json_encode($villesStats) ?>;

// Graphique 1 : Top 5 villes
new Chart(document.getElementById('sitogramme'), {
    type: 'bar',
    data: {
        labels: Object.keys(villesTop),
        datasets: [{
            label: 'Nombre de recherches',
            data: Object.values(villesTop),
            backgroundColor: 'rgba(54, 162, 235, 0.6)',
            borderColor: 'rgba(54, 162, 235, 1)',
            borderWidth: 1
        }]
    },
    options: {
        indexAxis: 'y',
        scales: { y: { beginAtZero: true } },
        plugins: {
            title: {
                display: true,
                text: 'Top 5 des villes les plus recherchées'
            }
        }
    }
});

// Graphique 2 : Toutes les recherches
new Chart(document.getElementById('chartVilles'), {
    type: 'bar',
    data: {
        labels: Object.keys(villes),
        datasets: [{
            label: 'Recherches par ville',
            data: Object.values(villes),
            backgroundColor: 'rgba(75, 192, 192, 0.6)'
        }]
    },
    options: { indexAxis: 'y' }
});

// Infos Bourse via AlphaVantage
fetch("https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol=AAPL&apikey=JIXHOJRIUWMYR26Q")
    .then(res => res.json())
    .then(data => {
        const quote = data["Global Quote"];
        if (quote) {
            document.getElementById("bourse").innerHTML = `
                <p><strong>${quote["01. symbol"]}</strong></p>
                <p>Prix : ${quote["05. price"]} $</p>
                <p>Variation : ${quote["10. change percent"]}</p>`;
        }
    })
    .catch(() => {
        document.getElementById("bourse").innerText = "Erreur bourse.";
    });
</script>

<?php include("include/footer.inc.php"); ?>
