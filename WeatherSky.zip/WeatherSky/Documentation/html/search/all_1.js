var searchData=
[
  ['_28_20_24ipdata_5b_20_27city_27_5d_20_3f_3f_20_27inconnue_27_29_20_3f_3e_3c_2fli_20_3e_3c_20li_20_3elocalisation_0',['( $ipData[ &apos;city&apos;] ?? &apos;Inconnue&apos;) ?&gt;&lt;/li &gt;&lt; li &gt;Localisation',['../tech_8php.html#af2e32d8d136e7d3488aa854eeb3fe092',1,'tech.php']]]
];
