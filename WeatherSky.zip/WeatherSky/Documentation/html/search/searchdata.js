var indexSectionsWithContent =
{
  0: "$(_acdefghilmnrstw",
  1: "w",
  2: "cfhimst",
  3: "aceglnr",
  4: "$(_dei"
};

var indexSectionNames =
{
  0: "all",
  1: "namespaces",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Espaces de nommage",
  2: "Fichiers",
  3: "Fonctions",
  4: "Variables"
};

