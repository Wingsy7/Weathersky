var searchData=
[
  ['footer_2einc_2ephp_0',['footer.inc.php',['../footer_8inc_8php.html',1,'']]],
  ['functions_2einc_2ephp_1',['functions.inc.php',['../functions_8inc_8php.html',1,'']]]
];
