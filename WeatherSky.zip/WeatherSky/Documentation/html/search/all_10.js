var searchData=
[
  ['tech_2ephp_0',['tech.php',['../tech_8php.html',1,'']]]
];
