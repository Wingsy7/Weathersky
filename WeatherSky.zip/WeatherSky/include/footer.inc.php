<footer>
    <p class="copyright">
        Cozma Miroslav &amp; Deborah Piaki, étudiant·e·s à 
        <a href="https://www.cyu.fr/">Cergy Université</a>.
    </p>
    <p>Dernière mise à jour: <time datetime="2025-03-10">11/03/2025</time></p>
    <p>L2-Informatique</p>
    <p><a href="index.php">Accueil</a></p>
    <p><a href="sitemap.php">Plan du Site</a></p>
    <p><a href="tech.php">Page Tech du projet de Dev Web</a></p>
</footer>
