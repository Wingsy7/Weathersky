<?php
/**
 * 📦 Fonctions principales du projet WeatherSky
 *
 * Ce fichier regroupe les fonctions permettant :
 * - La récupération de la localisation du visiteur
 * - L'appel à l'API APOD de la NASA
 * - La lecture et liaison des fichiers CSV
 * - La déduction de la région depuis un code INSEE
 *
 * @package WeatherSky
 * @author  Votre Nom
 * @version 1.0
 * @since   2025-04
 */

/**
 * Retourne la date du jour au format 'YYYY-MM-DD'.
 *
 * @return string Date du jour formatée
 */
function getTodayDate() {
    return date("Y-m-d");
}

/**
 * Récupère l’image du jour (APOD) depuis l’API de la NASA.
 *
 * @return string HTML contenant l’image ou la vidéo APOD
 */
function getAPODImage(): string {
    $api_key = "DEMO_KEY"; // Remplace par ta clé API personnelle
    $date = getTodayDate();

    $url = "https://api.nasa.gov/planetary/apod?api_key=$api_key&date=$date";
    $response = @file_get_contents($url);

    if ($response === false) {
        return '<p>Impossible de récupérer l’image du jour. Veuillez réessayer plus tard.</p>';
    }

    $data = json_decode($response, true);
    if (!$data || !isset($data['media_type']) || !isset($data['url'])) {
        return '<p>Données invalides reçues depuis l’API NASA.</p>';
    }

    if ($data['media_type'] === 'video') {
        return '<div class="apod-video">
            <iframe width="560" height="315" src="' . $data['url'] . '" frameborder="0" allowfullscreen></iframe>
            <p>' . htmlspecialchars($data['title'] ?? '') . '</p>
            <p>' . htmlspecialchars($data['explanation'] ?? '') . '</p>
        </div>';
    } else {
        return '<figure>
            <img src="' . htmlspecialchars($data['url']) . '" alt="APOD Image" class="apodNasa">
            <figcaption>' . htmlspecialchars($data['explanation']) . '</figcaption>
        </figure>';
    }
}

/**
 * Récupère la position approximative du visiteur via GeoPlugin (XML).
 *
 * @return array Tableau contenant la ville, région, pays, latitude, longitude
 */
function getVisitorLocationXML() {
    $api_url = 'http://www.geoplugin.net/xml.gp?ip=' . $_SERVER['REMOTE_ADDR'];
    $response = file_get_contents($api_url);
    $data = simplexml_load_string($response);

    return [
        'city' => (string)$data->geoplugin_city,
        'region' => (string)$data->geoplugin_region,
        'country' => (string)$data->geoplugin_countryName,
        'latitude' => (float)$data->geoplugin_latitude,
        'longitude' => (float)$data->geoplugin_longitude
    ];
}

/**
 * Retourne l’adresse IP réelle du visiteur.
 *
 * @return string IP du visiteur
 */
function getUserIP() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        return $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        return $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        return $_SERVER['REMOTE_ADDR'];
    }
}

/**
 * Récupère la localisation via IPInfo.io (JSON).
 *
 * @return array Tableau contenant la ville, région, pays, latitude, longitude
 */
function getVisitorLocationJSON() {
    $user_ip = getUserIP();
    $api_url = "https://ipinfo.io/$user_ip/json";

    $response = file_get_contents($api_url);
    $data = json_decode($response, true);

    return [
        'city' => $data['city'],
        'region' => $data['region'],
        'country' => $data['country'],
        'latitude' => isset($data['loc']) ? explode(',', $data['loc'])[0] : null,
        'longitude' => isset($data['loc']) ? explode(',', $data['loc'])[1] : null
    ];
}

/**
 * Récupère la localisation via WhatIsMyIP (XML).
 *
 * @return array|null Localisation du visiteur (ville, région, pays)
 */
function getVisitorLocationWIP() {
    $user_ip = getUserIP();
    $api_key = "e964f74aadfe25702230dfcbac03a675";
    $api_url = "https://api.whatismyip.com/ip-address-lookup.php?key=$api_key&input=$user_ip&output=xml";

    $response = file_get_contents($api_url);
    $data = simplexml_load_string($response);

    if (isset($data->query_status) && $data->query_status->query_status_code == "OK") {
        return [
            'city' => (string)$data->server_data->city,
            'region' => (string)$data->server_data->region,
            'country' => (string)$data->server_data->country
        ];
    }
    return null;
}

/**
 * Tente plusieurs services pour obtenir la meilleure position du visiteur.
 *
 * @return array Tableau de localisation
 */
function getBestVisitorLocation() {
    $location = getVisitorLocationXML();

    if (empty($location['city']) || empty($location['latitude'])) {
        $location = getVisitorLocationJSON();
    }

    if (empty($location['city'])) {
        $location = getVisitorLocationWIP();
    }

    return $location;
}

/**
 * Version dédiée à l’API WhatIsMyIP.
 *
 * @return array Localisation brute depuis WhatIsMyIP
 */
function getVisitorLocationFromWhatIsMyIP() {
    $user_ip = getUserIP();
    $api_key = "e964f74aadfe25702230dfcbac03a675";
    $api_url = "https://api.whatismyip.com/ip-address-lookup.php?key=$api_key&input=$user_ip&output=xml";

    $response = file_get_contents($api_url);
    $data = simplexml_load_string($response);

    return [
        'city' => (string)$data->city,
        'region' => (string)$data->region,
        'country' => (string)$data->country
    ];
}

/**
 * Lit un fichier CSV et retourne un tableau associatif.
 *
 * @param string $fichier    Chemin du fichier CSV
 * @param string $separateur Caractère séparateur (par défaut ",")
 * @return array Données lues depuis le CSV
 */
function lireCSV($fichier, $separateur = ",") {
    $resultat = [];

    if (!file_exists($fichier)) return [];

    if (($handle = fopen($fichier, "r")) !== false) {
        $entetes = fgetcsv($handle, 1000, $separateur);
        if (!$entetes) return [];

        while (($ligne = fgetcsv($handle, 1000, $separateur)) !== false) {
            if (count($ligne) === count($entetes)) {
                $resultat[] = array_combine($entetes, $ligne);
            }
        }
        fclose($handle);
    }

    return $resultat;
}

/**
 * Trouve la région associée à une ville via son code INSEE.
 *
 * @param string $codeINSEE Code INSEE de la ville
 * @param array  $villes    Données des villes
 * @param array  $departements Données des départements
 * @param array  $regions   Données des régions
 * @return string Nom de la région ou "Région inconnue"
 */
function getRegionFromVille($codeINSEE, $villes, $departements, $regions) {
    foreach ($villes as $ville) {
        if ($ville[0] == $codeINSEE) {
            $depCode = $ville[3];
            foreach ($departements as $dep) {
                if ($dep['DEP'] == $depCode) {
                    $regCode = $dep['REG'];
                    foreach ($regions as $region) {
                        if ($region['REG'] == $regCode) {
                            return $region['LIBELLE'];
                        }
                    }
                }
            }
        }
    }
    return "Région inconnue";
}
